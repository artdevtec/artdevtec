CompPages["menu"] = function(c) {

    const mkMenu = (items) => {
        const rows = items.map((item, i) => {
            const first = i === 0 && items.length > 1
            const last  = i === items.length - 1 && items.length > 1
            const only  = items.length === 1
            const r = only ? 'border-radius:12px;' : first ? 'border-radius:12px 12px 4px 4px;' : last ? 'border-radius:4px 4px 12px 12px;' : 'border-radius:4px;'
            const iconHtml = item.icon ? `<span class="piece-menu-icon material-symbols-rounded" translate="no">${item.icon}</span>` : ''
            const trailHtml = item.trail ? `<span class="piece-menu-trailing text-color-auto-14">${item.trail}</span>` : ''
            return `<li class="piece-surface background-color-auto-05 background-color-auto-06-hover text-color-auto-21" style="${r}cursor:pointer;display:flex;align-items:center;gap:12px;padding:0 12px;height:48px;font-size:14px;position:relative;">
                ${iconHtml}
                <span class="piece-menu-label">${item.label}</span>
                ${trailHtml}
            </li>`
        })
        return `<div class="piece-menu piece-surface background-color-auto-04" style="min-width:200px;">
            <ul style="list-style:none;padding:4px;margin:0;display:grid;gap:2px;">
                ${rows.join('')}
            </ul>
        </div>`
    }

    H.render(c,
        H.header("Menu", "Lista de opções em dropdown. Bordas arredondadas adaptam-se à posição do item (primeiro/último/único).", "menu.css"),

        H.section("SIMPLES — Só rótulo"),
        H.demo(null,
            mkMenu([
                {label:'Editar'},{label:'Duplicar'},{label:'Arquivar'},{label:'Excluir'}
            ]),
            `<div class="piece-menu piece-surface background-color-auto-04">
    <ul>
        <li> ... <!-- primeiro: border-radius: 12px 12px 4px 4px --> </li>
        <li> ... <!-- meio: border-radius: 4px --> </li>
        <li> ... <!-- último: border-radius: 4px 4px 12px 12px --> </li>
    </ul>
</div>`
        ),

        H.section("COM ÍCONES LEADING"),
        H.demo(null,
            mkMenu([
                {icon:'edit',      label:'Editar'},
                {icon:'content_copy', label:'Duplicar'},
                {icon:'archive',   label:'Arquivar'},
                {icon:'delete',    label:'Excluir'},
            ]),
            `<li style="border-radius:12px 12px 4px 4px; ...">
    <span class="piece-menu-icon material-symbols-rounded">edit</span>
    <span class="piece-menu-label">Editar</span>
</li>`
        ),

        H.section("COM TRAILING TEXT"),
        H.demo(null,
            mkMenu([
                {icon:'cut',    label:'Recortar',  trail:'Ctrl+X'},
                {icon:'content_copy', label:'Copiar', trail:'Ctrl+C'},
                {icon:'content_paste', label:'Colar', trail:'Ctrl+V'},
            ]),
            `<li>
    <span class="piece-menu-icon material-symbols-rounded">cut</span>
    <span class="piece-menu-label">Recortar</span>
    <span class="piece-menu-trailing">Ctrl+X</span>
</li>`
        ),

        H.section("PIECE-GAP — Múltiplos grupos"),
        H.demo(null,
            `<div class="piece-menu piece-gap piece-surface" style="min-width:200px;display:grid;gap:2px;">
                ${mkMenu([{icon:'edit',label:'Editar'},{icon:'content_copy',label:'Duplicar'}])}
                ${mkMenu([{icon:'archive',label:'Arquivar'},{icon:'delete',label:'Excluir'}])}
            </div>`,
            `<div class="piece-menu piece-gap">
    <ul> <!-- grupo 1 --> </ul>
    <ul> <!-- grupo 2 --> </ul>
</div>`
        ),

        H.section("REFERÊNCIA DE CLASSES"),
        H.ref([
            [".piece-menu",           "Container — max-width 280px, border-radius 16px"],
            [".piece-gap",            "Múltiplos grupos separados com sombra individual"],
            ["ul > li",               "Item — height 48px, font-size 14px"],
            [".piece-menu-icon",      "Ícone leading (font-size 20px)"],
            [".piece-menu-label",     "Rótulo do item (flex:1)"],
            [".piece-menu-trailing",  "Texto à direita (ex: atalho de teclado)"],
            [".piece-actived / :has(input:checked)", "Item selecionado — ícone filled"],
        ])
    )
}
